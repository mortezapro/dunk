<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DiscountModel extends Model
{
    protected $table = 'tbl_discount';
    protected $primaryKey = 'id';
    protected $fillable=['discount_code','status','created_at'];
    public $timestamps = true;
    public function setUpdatedAt($value)
    {
        // Do nothing.
    }
}
